const bcrypt = require("bcryptjs");
const SCHEMA = `
create table if not exists barbers(id text primary key, name text not null, specialty text not null, login text unique not null, password_hash text not null, telegram_chat_id text);
create table if not exists services(id text primary key, name text not null, price int not null, duration int not null);
create table if not exists bookings(id serial primary key, customer_name text not null, phone text not null, barber_id text not null references barbers(id), service_id text not null references services(id), date text not null, start_time text not null, end_time text not null, status text not null default 'pending' check (status in ('pending','confirmed','cancelled','completed')), note text default '', created_at timestamptz default now());
create index if not exists bk_lookup on bookings(barber_id, date);
create index if not exists bk_phone on bookings(phone);
create table if not exists working_hours(barber_id text references barbers(id), weekday int check (weekday between 0 and 6), start_time text, end_time text, primary key(barber_id, weekday));
create table if not exists breaks(barber_id text primary key references barbers(id), start_time text, end_time text);
alter table barbers enable row level security;
alter table services enable row level security;
alter table bookings enable row level security;
alter table working_hours enable row level security;
alter table breaks enable row level security;`;
const BARBERS = [["aziz", "Aziz", "Men's Haircut"], ["bek", "Bek", "Fade & Styling"], ["sardor", "Sardor", "Haircut & Beard"]];
const SERVICES = [["cut", "Soch olish", 50000, 40], ["both", "Soch + soqol", 80000, 40], ["beard", "Soqol", 40000, 40]];

module.exports = async function init(pool) {
  await pool.query(SCHEMA);
  for (const s of SERVICES)
    await pool.query("insert into services values($1,$2,$3,$4) on conflict(id) do update set name=$2, price=$3, duration=$4", s);
  for (const [id, name, spec] of BARBERS) {
    const { rows } = await pool.query("select 1 from barbers where id=$1", [id]);
    if (rows.length) continue;
    const key = "PASS_" + id.toUpperCase(), pw = process.env[key];
    if (!pw || pw.length < 8) { console.warn(`! ${id}: ${key} yo'q yoki 8 belgidan qisqa, sartarosh yaratilmadi`); continue; }
    await pool.query("insert into barbers(id,name,specialty,login,password_hash) values($1,$2,$3,$1,$4)", [id, name, spec, await bcrypt.hash(pw, 10)]);
    for (let d = 0; d < 7; d++)
      await pool.query("insert into working_hours values($1,$2,$3,$4)", [id, d, d === 0 ? null : "09:00", d === 0 ? null : "19:00"]);
    await pool.query("insert into breaks values($1,'13:00','13:40')", [id]);
    console.log("Sartarosh yaratildi:", id);
  }
};
