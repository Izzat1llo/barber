const express = require("express"), crypto = require("crypto"), path = require("path");
const bcrypt = require("bcryptjs"), { Pool } = require("pg"), init = require("./init");
const E = process.env, PORT = E.PORT || 3000, STEP = 40, TZ = "Asia/Tashkent";
if (!E.DATABASE_URL || !E.SESSION_SECRET) { console.error("DATABASE_URL va SESSION_SECRET kerak"); process.exit(1); }
const pool = new Pool({ connectionString: E.DATABASE_URL, ssl: /localhost|127\.0\.0\.1/.test(E.DATABASE_URL) ? false : { rejectUnauthorized: false } });
const q = (t, p) => pool.query(t, p).then(r => r.rows);
const app = express(); app.set("trust proxy", 1); app.use(express.json({ limit: "20kb" }));

// ---------- helpers ----------
const toM = t => { const [a, b] = t.split(":"); return +a * 60 + +b; };
const toT = m => String(Math.floor(m / 60)).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0");
const isDate = s => /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(new Date(s + "T00:00:00Z"));
const isTime = s => /^([01]\d|2[0-3]):[0-5]\d$/.test(s);
const addDays = (d, n) => { const x = new Date(d + "T00:00:00Z"); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); };
function nowTk() {
  const p = Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date()).map(x => [x.type, x.value]));
  return { date: `${p.year}-${p.month}-${p.day}`, min: +p.hour * 60 + +p.minute };
}
const esc = s => String(s).replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
const err = (res, e) => { console.error(e); res.status(500).json({ error: "server" }); };
const ah = fn => (req, res) => fn(req, res).catch(e => err(res, e));
const pub = r => ({ id: r.id, customerName: r.customer_name, phone: r.phone, barberId: r.barber_id, serviceId: r.service_id, date: r.date, startTime: r.start_time, endTime: r.end_time, status: r.status, note: r.note });
const hits = new Map();
const limit = (key, max, ms) => { const n = Date.now(), a = (hits.get(key) || []).filter(t => n - t < ms); a.push(n); hits.set(key, a); return a.length <= max; };
setInterval(() => { const n = Date.now(); for (const [k, a] of hits) if (!a.some(t => n - t < 3600e3)) hits.delete(k); }, 600e3).unref();

// ---------- tokens ----------
const mac = b => crypto.createHmac("sha256", E.SESSION_SECRET).update(b).digest("base64url");
const sign = p => { const b = Buffer.from(JSON.stringify(p)).toString("base64url"); return b + "." + mac(b); };
function verify(t) {
  try {
    const [b, s] = String(t).split("."), ok = mac(b);
    if (s.length !== ok.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(ok))) return null;
    const p = JSON.parse(Buffer.from(b, "base64url")); return p.exp > Date.now() ? p : null;
  } catch (e) { return null; }
}
const auth = (req, res, next) => { const p = verify((req.headers.authorization || "").replace("Bearer ", "")); if (!p) return res.status(401).json({ error: "auth" }); req.bid = p.id; next(); };

// ---------- telegram ----------
const TG = E.BOT_TOKEN ? `https://api.telegram.org/bot${E.BOT_TOKEN}` : null;
async function tg(method, body) {
  if (!TG) return null;
  try { const r = await fetch(TG + "/" + method, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); return await r.json(); }
  catch (e) { console.error("telegram:", e.message); return null; }
}
function notify(bar, svc, r) {
  if (!bar.telegram_chat_id) return;
  tg("sendMessage", {
    chat_id: bar.telegram_chat_id, parse_mode: "HTML",
    text: `🆕 <b>Yangi bron</b>\n👤 ${esc(r.customer_name)}\n📞 ${r.phone}\n✂️ ${esc(svc.name)}\n📅 ${r.date}  ${r.start_time}–${r.end_time}` + (r.note ? `\n📝 ${esc(r.note)}` : ""),
    reply_markup: { inline_keyboard: [[{ text: "✅ Tasdiqlash", callback_data: "c:" + r.id }, { text: "❌ Bekor qilish", callback_data: "x:" + r.id }]] }
  });
}

// ---------- schedules ----------
async function schedules() {
  const out = {};
  for (const b of await q("select id from barbers")) out[b.id] = { days: { 0: null, 1: null, 2: null, 3: null, 4: null, 5: null, 6: null }, brk: null };
  for (const r of await q("select * from working_hours")) if (out[r.barber_id]) out[r.barber_id].days[r.weekday] = r.start_time && r.end_time ? [r.start_time, r.end_time] : null;
  for (const r of await q("select * from breaks")) if (out[r.barber_id]) out[r.barber_id].brk = r.start_time ? [r.start_time, r.end_time] : null;
  return out;
}

// ---------- public API ----------
app.get("/health", ah(async (req, res) => { await q("select 1"); res.send("ok"); }));

app.get("/api/public", ah(async (req, res) => {
  const t = nowTk();
  const bookings = await q(`select barber_id as "barberId", date, start_time as "startTime", end_time as "endTime", status from bookings where status<>'cancelled' and date>=$1 and date<=$2`, [t.date, addDays(t.date, 60)]);
  res.json({ bookings, schedules: await schedules() });
}));

app.post("/api/bookings", async (req, res) => {
  const b = req.body || {};
  if (!limit("bk:" + req.ip, 10, 3600e3)) return res.status(429).json({ error: "rate" });
  const name = String(b.customerName || "").trim().slice(0, 60), note = String(b.note || "").trim().slice(0, 200);
  const phone = "+998" + String(b.phone || "").replace(/\D/g, "").slice(-9);
  if (name.length < 2 || phone.length !== 13 || !isDate(b.date) || !isTime(b.startTime)) return res.status(400).json({ error: "invalid" });
  const c = await pool.connect();
  try {
    const bar = (await c.query("select id,name,telegram_chat_id from barbers where id=$1", [String(b.barberId)])).rows[0];
    const svc = (await c.query("select * from services where id=$1", [String(b.serviceId)])).rows[0];
    if (!bar || !svc) return res.status(400).json({ error: "invalid" });
    const now = nowTk();
    if (b.date < now.date || b.date > addDays(now.date, 60)) return res.status(400).json({ error: "date" });
    await c.query("begin");
    await c.query("select pg_advisory_xact_lock(hashtext($1))", [bar.id + b.date]);
    const wd = new Date(b.date + "T00:00:00Z").getUTCDay();
    const w = (await c.query("select start_time,end_time from working_hours where barber_id=$1 and weekday=$2", [bar.id, wd])).rows[0];
    const br = (await c.query("select start_time,end_time from breaks where barber_id=$1", [bar.id])).rows[0];
    const s = toM(b.startTime), e = s + svc.duration;
    let ok = !!(w && w.start_time && w.end_time && s >= toM(w.start_time) && e <= toM(w.end_time) && (s - toM(w.start_time)) % STEP === 0);
    if (ok && br && br.start_time && s < toM(br.end_time) && e > toM(br.start_time)) ok = false;
    if (ok && b.date === now.date && s <= now.min) ok = false;
    if (ok) {
      const rows = (await c.query("select start_time,end_time from bookings where barber_id=$1 and date=$2 and status<>'cancelled'", [bar.id, b.date])).rows;
      if (rows.some(r => s < toM(r.end_time) && e > toM(r.start_time))) ok = false;
    }
    if (!ok) { await c.query("rollback"); return res.status(409).json({ error: "taken" }); }
    const row = (await c.query("insert into bookings(customer_name,phone,barber_id,service_id,date,start_time,end_time,status,note) values($1,$2,$3,$4,$5,$6,$7,'pending',$8) returning *", [name, phone, bar.id, svc.id, b.date, b.startTime, toT(e), note])).rows[0];
    await c.query("commit");
    res.json(pub(row));
    notify(bar, svc, row);
  } catch (e) { try { await c.query("rollback"); } catch (_) {} err(res, e); }
  finally { c.release(); }
});

app.get("/api/my", ah(async (req, res) => {
  if (!limit("my:" + req.ip, 30, 3600e3)) return res.status(429).json({ error: "rate" });
  const d = String(req.query.phone || "").replace(/\D/g, "").slice(-9);
  if (d.length !== 9) return res.status(400).json({ error: "invalid" });
  res.json((await q("select * from bookings where phone=$1 order by date desc, start_time desc limit 50", ["+998" + d])).map(pub));
}));

// ---------- barber API ----------
app.post("/api/login", ah(async (req, res) => {
  const login = String((req.body || {}).login || "").trim().toLowerCase(), password = String((req.body || {}).password || "");
  if (!limit("lg:" + req.ip + ":" + login, 5, 15 * 60e3)) return res.status(429).json({ error: "rate" });
  const b = (await q("select * from barbers where login=$1", [login]))[0];
  if (!b || !(await bcrypt.compare(password, b.password_hash))) return res.status(401).json({ error: "auth" });
  res.json({ token: sign({ id: b.id, exp: Date.now() + 12 * 3600e3 }) });
}));

app.get("/api/me", auth, ah(async (req, res) => {
  const b = (await q("select id,name,telegram_chat_id from barbers where id=$1", [req.bid]))[0];
  res.json({ barber: { id: b.id, name: b.name, telegramChatId: b.telegram_chat_id }, schedule: (await schedules())[req.bid] });
}));

app.get("/api/me/bookings", auth, ah(async (req, res) => {
  const t = nowTk();
  res.json((await q("select * from bookings where barber_id=$1 and date>=$2 order by date, start_time", [req.bid, t.date])).map(pub));
}));

app.patch("/api/me/bookings/:id", auth, ah(async (req, res) => {
  const st = (req.body || {}).status;
  if (!["confirmed", "cancelled", "completed"].includes(st) || !Number.isInteger(+req.params.id)) return res.status(400).json({ error: "invalid" });
  const rows = await q("update bookings set status=$1 where id=$2 and barber_id=$3 returning *", [st, +req.params.id, req.bid]);
  rows.length ? res.json(pub(rows[0])) : res.status(404).json({ error: "none" });
}));

app.put("/api/me/schedule", auth, ah(async (req, res) => {
  const { days, brk } = req.body || {};
  const okW = w => w === null || (Array.isArray(w) && isTime(w[0]) && isTime(w[1]) && toM(w[1]) > toM(w[0]));
  if (!days || !Array.isArray(brk) || !okW(brk) || ![0, 1, 2, 3, 4, 5, 6].every(d => okW(days[d]))) return res.status(400).json({ error: "invalid" });
  const c = await pool.connect();
  try {
    await c.query("begin");
    await c.query("delete from working_hours where barber_id=$1", [req.bid]);
    for (let d = 0; d < 7; d++) await c.query("insert into working_hours values($1,$2,$3,$4)", [req.bid, d, days[d] ? days[d][0] : null, days[d] ? days[d][1] : null]);
    await c.query("insert into breaks values($1,$2,$3) on conflict(barber_id) do update set start_time=$2, end_time=$3", [req.bid, brk[0], brk[1]]);
    await c.query("commit"); res.json({ ok: true });
  } catch (e) { try { await c.query("rollback"); } catch (_) {} err(res, e); }
  finally { c.release(); }
}));

app.put("/api/me/telegram", auth, ah(async (req, res) => {
  const id = String((req.body || {}).chatId || "").trim();
  if (id && !/^-?\d{5,15}$/.test(id)) return res.status(400).json({ error: "invalid" });
  await q("update barbers set telegram_chat_id=$1 where id=$2", [id || null, req.bid]);
  if (id) await tg("sendMessage", { chat_id: id, text: "✅ BARBERBOOK: Telegram ulandi. Yangi bronlar shu yerga keladi." });
  res.json({ ok: true });
}));

// ---------- telegram webhook (ID olish + tugmalar) ----------
app.post("/telegram/webhook", async (req, res) => {
  if (!E.WEBHOOK_SECRET || req.headers["x-telegram-bot-api-secret-token"] !== E.WEBHOOK_SECRET) return res.sendStatus(403);
  res.sendStatus(200);
  const u = req.body || {};
  try {
    if (u.message && String(u.message.text || "").startsWith("/start")) {
      const id = u.message.chat.id;
      await tg("sendMessage", { chat_id: id, parse_mode: "HTML", text: `Salom! Sizning Telegram ID raqamingiz: <code>${id}</code>\nUni BARBERBOOK panelidagi "Telegram ID" maydoniga kiriting.` });
    }
    if (u.callback_query) {
      const cq = u.callback_query, [a, id] = String(cq.data).split(":");
      const st = a === "c" ? "confirmed" : a === "x" ? "cancelled" : null;
      if (st && Number.isInteger(+id)) {
        const rows = await q("update bookings set status=$1 where id=$2 and barber_id in (select id from barbers where telegram_chat_id=$3) returning id", [st, +id, String(cq.message.chat.id)]);
        await tg("answerCallbackQuery", { callback_query_id: cq.id, text: rows.length ? (st === "confirmed" ? "Tasdiqlandi ✅" : "Bekor qilindi ❌") : "Xatolik" });
        if (rows.length) await tg("editMessageReplyMarkup", { chat_id: cq.message.chat.id, message_id: cq.message.message_id, reply_markup: { inline_keyboard: [] } });
      }
    }
  } catch (e) { console.error(e); }
});

// ---------- haftalik zaxira nusxa (GitHub Actions chaqiradi) ----------
app.post("/api/cron/backup", ah(async (req, res) => {
  if (!E.CRON_SECRET || req.headers["x-cron-secret"] !== E.CRON_SECRET) return res.sendStatus(403);
  if (!TG || !E.ADMIN_CHAT_ID) return res.status(400).json({ error: "telegram sozlanmagan" });
  const rows = await q("select * from bookings order by date, start_time");
  const cols = ["id", "customer_name", "phone", "barber_id", "service_id", "date", "start_time", "end_time", "status", "note", "created_at"];
  const csv = [cols.join(",")].concat(rows.map(r => cols.map(c => '"' + String(r[c] == null ? "" : r[c]).replace(/"/g, '""') + '"').join(","))).join("\n");
  const f = new FormData();
  f.append("chat_id", E.ADMIN_CHAT_ID); f.append("caption", "BARBERBOOK zaxira: " + rows.length + " ta bron");
  f.append("document", new Blob(["\ufeff" + csv], { type: "text/csv" }), "bookings-" + nowTk().date + ".csv");
  const r = await fetch(TG + "/sendDocument", { method: "POST", body: f });
  res.json({ ok: r.ok, count: rows.length });
}));

app.use(express.static(path.join(__dirname, "public")));

init(pool).then(() => app.listen(PORT, () => {
  console.log("BARBERBOOK ishga tushdi, port " + PORT);
  if (TG && E.PUBLIC_URL && E.WEBHOOK_SECRET) tg("setWebhook", { url: E.PUBLIC_URL.replace(/\/$/, "") + "/telegram/webhook", secret_token: E.WEBHOOK_SECRET, allowed_updates: ["message", "callback_query"] });
})).catch(e => { console.error("Baza xatosi:", e.message); process.exit(1); });
