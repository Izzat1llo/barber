# BARBERBOOK server (Node + Postgres + Telegram)

Mijozlar bron qiladi, har bir sartarosh o'z login/paroli bilan faqat o'z bronlarini ko'radi va Telegramda yangi bron haqida xabar oladi.
Ish vaqti: 09:00–19:00 (Du–Sh), tushlik 13:00–13:40, har bir xizmat 40 daqiqa.

## 1-qadam. Telegram bot
1. Telegramda **@BotFather** ga `/newbot` yozing, nom bering. U sizga **token** beradi (buni hech kimga yubormang).

## 2-qadam. Baza (Supabase, tekin)
1. supabase.com ga kiring, yangi loyiha yarating, baza parolini eslab qoling.
2. **Connect** tugmasi → **Session pooler** ulanish manzilini nusxalang (`postgresql://...`), ichidagi `[YOUR-PASSWORD]` o'rniga baza parolini yozing. Bu `DATABASE_URL` bo'ladi.
   (Jadvallarni o'zi yaratadi, qo'lda hech narsa qilish shart emas.)

## 3-qadam. Kodni GitHub'ga yuklash
1. github.com da yangi repository (Private) yarating va shu papkadagi hamma fayllarni yuklang (`.env` fayli bo'lmasin).

## 4-qadam. Server (Render, tekin)
1. render.com → **New → Web Service** → GitHub repository'ni tanlang.
2. Build Command: `npm install`  |  Start Command: `npm start`  |  Plan: **Free**.
3. **Environment** bo'limida `.env.example` dagi qiymatlarni kiriting:
   `DATABASE_URL`, `SESSION_SECRET` (uzun tasodifiy matn), `BOT_TOKEN`, `WEBHOOK_SECRET`, `CRON_SECRET`,
   `PASS_AZIZ`, `PASS_BEK`, `PASS_SARDOR` (sartaroshlarning parollari, 8+ belgi).
   `PUBLIC_URL` ni Render sayt manzili chiqqandan keyin qo'shing (masalan `https://barberbook.onrender.com`) va **Save** bosing.
4. Ishga tushgach: sayt manzilini oching. Loginlar: `aziz`, `bek`, `sardor`. Parollar yuqorida yozganlaringiz.
5. Sartaroshlar yaratilgach `PASS_...` o'zgaruvchilarini Render'dan **o'chirib tashlang**.

## 5-qadam. Telegram ID olish
1. Har bir sartarosh botga `/start` yozadi, bot unga ID raqamini yuboradi.
2. Sartarosh panelga kiradi → **Telegram** bo'limiga ID ni yozib Saqlaydi. Sinov xabari keladi.
3. O'zingiz ham botga `/start` yozing, ID ni Render'da `ADMIN_CHAT_ID` ga qo'ying (zaxira nusxalar shu yerga keladi).

## 6-qadam. Server uxlab qolmasligi (tekin)
Render tekin serveri 15 daqiqa faolsiz tursa uxlaydi. **uptimerobot.com** (tekin) da HTTP monitor yarating: `https://SAYTINGIZ/health`, har 5 daqiqada. Bu bazani ham faol tutadi (Supabase 7 kun faolsiz bo'lsa to'xtatadi).

## 7-qadam. Haftalik zaxira nusxa
GitHub repository → Settings → Secrets → Actions da ikkita secret qo'shing: `APP_URL` (sayt manzili, oxirida `/`siz) va `CRON_SECRET` (Render'dagi bilan bir xil).
Har dushanba barcha bronlar CSV fayl bo'lib sizning Telegramingizga keladi. Sinash uchun Actions → weekly-backup → Run workflow.

## Parolni o'zgartirish
Kompyuterda: `DATABASE_URL="..." node scripts/reset-password.js aziz yangiParol123`

## Eslatma
Xizmat narxi/davomiyligini o'zgartirsangiz: `init.js` (SERVICES) va `public/index.html` (SERVICES) ikkalasida ham o'zgartiring.
