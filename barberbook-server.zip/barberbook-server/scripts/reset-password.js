// Ishlatish: DATABASE_URL="..." node scripts/reset-password.js aziz yangiParol123
const { Pool } = require("pg"), bcrypt = require("bcryptjs");
const [id, pw] = process.argv.slice(2);
if (!id || !pw || pw.length < 8) { console.log("Ishlatish: node scripts/reset-password.js <login> <parol (8+ belgi)>"); process.exit(1); }
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
bcrypt.hash(pw, 10).then(h => pool.query("update barbers set password_hash=$1 where login=$2", [h, id.toLowerCase()]))
  .then(r => { console.log(r.rowCount ? "Parol yangilandi" : "Bunday login topilmadi"); return pool.end(); })
  .catch(e => { console.error(e.message); process.exit(1); });
